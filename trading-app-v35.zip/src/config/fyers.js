require("dotenv").config();
const fs  = require("fs");
const path = require("path");
const { fyersModel } = require("fyers-api-v3");

const fyers = new fyersModel({
  path: "./logs",
  enableLogging: true,
});

fyers.setAppId(process.env.APP_ID);
fyers.setRedirectUrl(process.env.REDIRECT_URL);

// ── Token persistence ─────────────────────────────────────────────────────────
// Fyers access token is stored to disk so it survives nodemon restarts.
// Token file lives in /data/.fyers_token (gitignored, never committed).
// ─────────────────────────────────────────────────────────────────────────────

const TOKEN_FILE = path.join(__dirname, "../../data/.fyers_token");

function saveToken(token) {
  try {
    const dir = path.dirname(TOKEN_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(TOKEN_FILE, JSON.stringify({ token, savedAt: Date.now() }), "utf-8");
  } catch (err) {
    console.warn("⚠️  Could not save Fyers token to disk:", err.message);
  }
}

function loadToken() {
  try {
    if (!fs.existsSync(TOKEN_FILE)) return null;
    const { token, savedAt } = JSON.parse(fs.readFileSync(TOKEN_FILE, "utf-8"));
    // Fyers tokens expire at midnight — discard if older than 20 hours
    const ageHours = (Date.now() - savedAt) / (1000 * 60 * 60);
    if (ageHours > 20) {
      fs.unlinkSync(TOKEN_FILE);
      console.log("🕐 Fyers token expired (>20h old) — please login again.");
      return null;
    }
    return token;
  } catch (err) {
    return null;
  }
}

// Auto-restore token on startup (survives nodemon restart)
const savedToken = loadToken();
if (savedToken) {
  fyers.setAccessToken(savedToken);
  process.env.ACCESS_TOKEN = savedToken;
  console.log("✅ [Fyers] Token restored from disk — no need to login again.");
}

// Patch setAccessToken to also persist to disk
const _originalSetToken = fyers.setAccessToken.bind(fyers);
fyers.setAccessToken = function(token) {
  _originalSetToken(token);
  process.env.ACCESS_TOKEN = token;
  saveToken(token);
};

module.exports = fyers;
