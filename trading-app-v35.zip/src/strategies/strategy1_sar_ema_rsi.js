/**
 * STRATEGY 5: SAR_EMA9_RSI
 *
 * ENTRY — BUY_CE (bullish):
 *   TRIGGER    : Candle HIGH touches/crosses EMA9 intra-candle (candle.high >= ema9)
 *                → price pushed up into EMA9 during the candle
 *   CONFIRM 1  : SAR trend = 1 (uptrend — dots are BELOW price, supporting the move up)
 *   CONFIRM 2  : RSI > 51 (bullish momentum)
 *   STOP LOSS  : Current SAR dot value (sitting below price)
 *
 * ENTRY — BUY_PE (bearish):
 *   TRIGGER    : Candle LOW touches/crosses EMA9 intra-candle (candle.low <= ema9)
 *                → price pushed down into EMA9 during the candle
 *   CONFIRM 1  : SAR trend = -1 (downtrend — dots are ABOVE price, pressing down)
 *   CONFIRM 2  : RSI < 49 (bearish momentum)
 *   STOP LOSS  : Current SAR dot value (sitting above price)
 *
 * KEY INSIGHT:
 *   SAR does NOT need to flip — it just needs to already be on the right side.
 *   A long downtrend has SAR dots above price (trend=-1). When price dips into EMA9
 *   with RSI < 49 → clean PE entry. SAR was already in the right position for ages.
 *   Similarly for CE: SAR dots below (trend=1), price touches EMA9 from below.
 *
 * EXIT: SAR trailing SL (on every tick) | Opposite signal | EOD 3:20 PM
 * Timeframe: 5-min | EMA: OHLC4 | Window: 9:30–3:00 PM IST
 */

const { EMA, RSI } = require("technicalindicators");

const NAME        = "SAR_EMA9_RSI";
const DESCRIPTION = "Intra-candle SAR breach | EMA9 strict slope | RSI 51/49 | Size>=10 | 9:30-3PM";

// ── Parabolic SAR (step=0.02, max=0.2) ───────────────────────────────────────
// trend=1  → uptrend,   SAR dots BELOW price
// trend=-1 → downtrend, SAR dots ABOVE price
function calcSAR(candles, step, max) {
  step = step || 0.02;
  max  = max  || 0.2;
  if (candles.length < 3) return [];

  var result = [];
  var trend  = 1;
  var sar    = candles[0].low;
  var ep     = candles[0].high;
  var af     = step;

  for (var i = 1; i < candles.length; i++) {
    var prev   = candles[i - 1];
    var curr   = candles[i];
    var newSar = sar + af * (ep - sar);

    if (trend === 1) {
      newSar = Math.min(newSar, prev.low, i >= 2 ? candles[i - 2].low : prev.low);
      if (curr.low < newSar) {
        trend = -1; newSar = ep; ep = curr.low; af = step;
      } else {
        if (curr.high > ep) { ep = curr.high; af = Math.min(af + step, max); }
      }
    } else {
      newSar = Math.max(newSar, prev.high, i >= 2 ? candles[i - 2].high : prev.high);
      if (curr.high > newSar) {
        trend = 1; newSar = ep; ep = curr.high; af = step;
      } else {
        if (curr.low < ep) { ep = curr.low; af = Math.min(af + step, max); }
      }
    }
    sar = newSar;
    result.push({ sar: parseFloat(sar.toFixed(2)), trend: trend });
  }
  return result;
}

function isInTradingWindow(unixSec) {
  var d        = new Date(new Date(unixSec * 1000).toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  var totalMin = d.getHours() * 60 + d.getMinutes();
  return totalMin >= 570 && totalMin < 900;
}

/**
 * getSignal(candles)
 *
 * TWO valid entry scenarios — both fire BUY_CE or BUY_PE:
 *
 * LOGIC 1 — EMA touch, SAR already positioned:
 *   CE: candle.high >= EMA9  AND  currSAR.trend=1 (dots already below price)  AND  RSI > 51
 *   PE: candle.low  <= EMA9  AND  currSAR.trend=-1 (dots already above price) AND  RSI < 49
 *
 * LOGIC 2 — EMA touch causes SAR to flip on the same candle:
 *   CE: candle.high >= EMA9  AND  SAR flipped -1→1 THIS candle (just moved below) AND  RSI > 51
 *   PE: candle.low  <= EMA9  AND  SAR flipped 1→-1 THIS candle (just moved above) AND  RSI < 49
 *
 * LOGIC 3 — SAR still BULL but strong bearish momentum override (PE only):
 *   PE: candle.low <= EMA9  AND  EMA9 falling  AND  close < EMA9
 *       AND  RSI < 40  AND  SAR dot is 50+ pts below close (SAR is lagging)
 *   Stop loss = EMA9 value (SAR too far away to be useful)
 *   This catches fast downmoves where SAR hasn't flipped yet.
 *
 * Stop loss = SAR dot (Logic 1 & 2) | EMA9 (Logic 3 override)
 */
function getSignal(candles) {
  if (candles.length < 30) {
    return {
      signal: "NONE",
      reason: "Warming up (" + candles.length + "/30 candles)",
      stopLoss: null,
      prevCandleHigh: null,
      prevCandleLow:  null,
    };
  }

  var signalCandle = candles[candles.length - 1];

  if (!isInTradingWindow(signalCandle.time)) {
    return {
      signal: "NONE",
      reason: "Outside 9:30 AM - 3:00 PM window",
      stopLoss: null,
      prevCandleHigh: signalCandle.high,
      prevCandleLow:  signalCandle.low,
    };
  }

  // ── Indicators ──────────────────────────────────────────────────────────────
  var ohlc4  = candles.map(function(c) { return (c.open + c.high + c.low + c.close) / 4; });
  var closes = candles.map(function(c) { return c.close; });

  var ema9arr = EMA.calculate({ period: 9, values: ohlc4 });
  var ema9    = ema9arr[ema9arr.length - 1];
  var ema9_1  = ema9arr[ema9arr.length - 2];

  var rsiArr = RSI.calculate({ period: 14, values: closes });
  var rsi    = rsiArr[rsiArr.length - 1];

  var sarArr  = calcSAR(candles);
  var currSAR = sarArr[sarArr.length - 1];  // SAR after this candle
  var prevSAR = sarArr[sarArr.length - 2];  // SAR after previous candle

  if (!currSAR || !prevSAR) {
    return {
      signal: "NONE",
      reason: "SAR not ready",
      stopLoss: null,
      prevCandleHigh: signalCandle.high,
      prevCandleLow:  signalCandle.low,
    };
  }

  var RSI_CE_MIN = 51;
  var RSI_PE_MAX = 49;

  // ── EMA9 intra-candle touch (the TRIGGER for both logics) ───────────────────
  var emaTouchCE = signalCandle.high >= ema9;   // candle reached up into/through EMA9
  var emaTouchPE = signalCandle.low  <= ema9;   // candle reached down into/through EMA9

  // Tiebreaker: if candle straddles EMA9 (both true), use close direction
  // Close above EMA9 → favour CE touch; close below → favour PE touch
  if (emaTouchCE && emaTouchPE) {
    if (signalCandle.close >= ema9) {
      emaTouchPE = false;  // closing above EMA9 → bullish bias → only CE valid
    } else {
      emaTouchCE = false;  // closing below EMA9 → bearish bias → only PE valid
    }
  }

  // ── SAR position checks ──────────────────────────────────────────────────────
  // Logic 1: SAR already on the right side before this candle
  var sarAlreadyBullish = currSAR.trend === 1;   // dots below price — supports CE
  var sarAlreadyBearish = currSAR.trend === -1;  // dots above price — supports PE

  // Logic 2: SAR flipped ON this candle (prevSAR was opposite, currSAR is now correct side)
  var sarJustFlippedBull = prevSAR.trend === -1 && currSAR.trend === 1;   // just moved below → CE
  var sarJustFlippedBear = prevSAR.trend === 1  && currSAR.trend === -1;  // just moved above → PE

  // Logic 3: SAR still BULL but price is in strong bearish momentum
  //   Allow PE entry when ALL of these are true:
  //   a) EMA9 is FALLING (ema9 < ema9_1) — downtrend confirmed on EMA
  //   b) Candle closes BELOW EMA9 — price has decisively crossed under
  //   c) RSI < 40 — strong bearish momentum (tighter than the normal 49 threshold)
  //   d) SAR dot is at least 50 pts BELOW current close — SAR is lagging far behind,
  //      price action has already moved well past it
  //   In this case we use the EMA9 value as SL instead of SAR (SAR is too far away)
  var sarBullOverridePE = (
    currSAR.trend === 1                          &&  // SAR still bullish (hasn't flipped yet)
    ema9 < ema9_1                                &&  // EMA9 is falling
    signalCandle.close < ema9                    &&  // close is below EMA9
    rsi < 40                                     &&  // strong bearish momentum
    (signalCandle.close - currSAR.sar) > 50         // SAR dot is 50+ pts below price (lagging)
  );

  // Combined SAR condition — either already positioned OR just flipped OR strong override
  var sarOkForCE = sarAlreadyBullish || sarJustFlippedBull;
  var sarOkForPE = sarAlreadyBearish || sarJustFlippedBear || sarBullOverridePE;

  // SL: normally the SAR dot value. For the bull-override PE case, use EMA9
  // (SAR is too far below price to be a useful stop — EMA9 is the resistance level)
  var sarSL = sarBullOverridePE
    ? parseFloat(ema9.toFixed(2))
    : parseFloat(currSAR.sar.toFixed(2));

  // Label for logging
  var sarLabelCE = sarJustFlippedBull ? "SAR_FLIP_BULL" : "SAR_BULL";
  var sarLabelPE = sarJustFlippedBear ? "SAR_FLIP_BEAR"
                 : sarBullOverridePE  ? "SAR_BULL_OVERRIDE(EMA_SL)"
                 : "SAR_BEAR";

  var base = {
    ema9:           parseFloat(ema9.toFixed(2)),
    ema9Prev:       parseFloat(ema9_1.toFixed(2)),
    ema9Falling:    ema9 < ema9_1,
    ema9Rising:     ema9 > ema9_1,
    rsi:            parseFloat(rsi.toFixed(1)),
    sar:            currSAR.sar,
    sarTrend:       currSAR.trend === 1 ? "BULLISH" : "BEARISH",
    sarTrendInt:    currSAR.trend,
    prevSarValue:   prevSAR.sar,
    prevSarTrend:   prevSAR.trend,
    emaTouchCE:     emaTouchCE,
    emaTouchPE:     emaTouchPE,
    prevCandleHigh: signalCandle.high,
    prevCandleLow:  signalCandle.low,
    stopLoss:       sarSL,
  };

  // ── BUY CE ──────────────────────────────────────────────────────────────────
  if (emaTouchCE && sarOkForCE) {
    // Sanity check: SAR SL must be BELOW current price for CE (dot below = bullish support)
    // If SL > close, the SAR dot is above price — trade would be in loss from the start
    if (sarSL >= signalCandle.close) {
      return Object.assign({}, base, {
        signal: "NONE",
        reason: "CE blocked: SAR SL ₹" + sarSL + " >= close ₹" + signalCandle.close + " (SL above price — invalid)",
      });
    }
    if (rsi > RSI_CE_MIN) {
      return Object.assign({}, base, {
        signal: "BUY_CE",
        reason: "EMA9 touch CE (high=" + signalCandle.high + " >= EMA9=" + ema9.toFixed(2) + ")" +
                " | " + sarLabelCE + " @ " + currSAR.sar +
                " | RSI=" + rsi.toFixed(1) +
                " | SL=" + sarSL,
      });
    }
    return Object.assign({}, base, {
      signal: "NONE",
      reason: "CE blocked [EMA+SAR ok]: RSI " + rsi.toFixed(1) + " <= " + RSI_CE_MIN,
    });
  }

  // ── BUY PE ──────────────────────────────────────────────────────────────────
  if (emaTouchPE && sarOkForPE) {
    // Sanity check: SAR SL must be ABOVE current price for PE (dot above = bearish pressure)
    // If SL < close, the SAR dot is below price — trade would be in loss from the start
    if (sarSL <= signalCandle.close) {
      return Object.assign({}, base, {
        signal: "NONE",
        reason: "PE blocked: SAR SL ₹" + sarSL + " <= close ₹" + signalCandle.close + " (SL below price — invalid)",
      });
    }
    if (rsi < RSI_PE_MAX) {
      return Object.assign({}, base, {
        signal: "BUY_PE",
        reason: "EMA9 touch PE (low=" + signalCandle.low + " <= EMA9=" + ema9.toFixed(2) + ")" +
                " | " + sarLabelPE + " @ " + currSAR.sar +
                " | RSI=" + rsi.toFixed(1) +
                " | SL=" + sarSL,
      });
    }
    return Object.assign({}, base, {
      signal: "NONE",
      reason: "PE blocked [EMA+SAR ok]: RSI " + rsi.toFixed(1) + " >= " + RSI_PE_MAX,
    });
  }

  // ── No signal ───────────────────────────────────────────────────────────────
  var noTouchReason = [];
  if (!emaTouchCE && !emaTouchPE) {
    noTouchReason.push("No EMA9 touch (high=" + signalCandle.high + " low=" + signalCandle.low + " EMA9=" + ema9.toFixed(2) + ")");
  } else if (emaTouchCE && !sarOkForCE) {
    noTouchReason.push("CE EMA touch but SAR bearish (dots above, trend=-1) — no flip either");
  } else if (emaTouchPE && !sarOkForPE) {
    noTouchReason.push("PE EMA touch but SAR bullish (dots below, trend=1) — no flip, no override" +
      " (need: EMA9 falling + close<EMA9 + RSI<40 + SAR 50pts below close)" +
      " | SAR=" + currSAR.sar + " close=" + signalCandle.close +
      " gap=" + (signalCandle.close - currSAR.sar).toFixed(1) + "pts" +
      " ema9Falling=" + (ema9 < ema9_1));
  }

  return Object.assign({}, base, {
    signal: "NONE",
    reason: noTouchReason.join(" | ") + " | SAR " + (currSAR.trend === 1 ? "BULL" : "BEAR") +
            " @ " + currSAR.sar + " | RSI=" + rsi.toFixed(1),
  });
}

module.exports = { NAME: NAME, DESCRIPTION: DESCRIPTION, getSignal: getSignal };
