/**
 * STRATEGY 2: 15-Min Opening Range Breakout (ORB)
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * CONCEPT — Opening Range Breakout:
 *   The first N candles of the day (9:15–10:15 AM with 15-min candles = 4 candles)
 *   form the "Opening Range": High = OR_HIGH, Low = OR_LOW.
 *   Once the range is established, the strategy waits for a decisive breakout.
 *
 * ENTRY — BUY_CE (bullish breakout):
 *   Trigger  : Candle CLOSES above OR_HIGH + buffer (0.1%)
 *   Confirm 1: RSI > 50 (bullish momentum direction)
 *   Confirm 2: Breakout candle body >= 5% of OR range (real close, not a wick poke)
 *   Stop Loss: OR_LOW (full range SL) — tightened by SAR if SAR is closer
 *
 * ENTRY — BUY_PE (bearish breakdown):
 *   Trigger  : Candle CLOSES below OR_LOW - buffer (0.1%)
 *   Confirm 1: RSI < 50 (bearish momentum direction)
 *   Confirm 2: Breakdown candle body >= 5% of OR range
 *   Stop Loss: OR_HIGH — tightened by SAR if SAR is closer
 *
 * OPENING RANGE DEFINITION:
 *   15-min candles, 4 candles from 9:15 AM → forms by 10:15 AM
 *   OR is reset every day at 9:15 AM
 *   Trading window opens AFTER the OR is complete (≥ 10:15 AM)
 *
 * EXIT RULES (same priority as backtest):
 *   1. 50% candle rule (prev candle mid cross) — via paper/live trade engine
 *   2. SAR trailing stop-loss (on every tick)
 *   3. Opposite breakout signal
 *   4. EOD square-off at 3:20 PM
 *
 * ADDITIONAL SAFEGUARDS:
 *   - Maximum 2 trades per day (prevents over-trading during choppy sessions)
 *   - False breakout filter: close must be > OR_HIGH (not just a wick poke)
 *   - Range size filter: OR range must be >= 30 points (skip very narrow ranges
 *     that produce whipsaw breakouts in gap-up/flat opens)
 *   - No re-entry in same direction on same day after SL hit
 *
 * TIMEFRAME: 15-min candles (set TRADE_RESOLUTION=15 in .env)
 * ─────────────────────────────────────────────────────────────────────────────
 */

const { RSI } = require("technicalindicators");

const NAME        = "15Min_ORB";
const DESCRIPTION = "15-min Opening Range Breakout | RSI>50 direction | body>5% OR | SAR SL | Max 2 trades/day";

// ── Parabolic SAR (step=0.02, max=0.2) ───────────────────────────────────────
function calcSAR(candles, step, max) {
  step = step || 0.02;
  max  = max  || 0.2;
  if (candles.length < 3) return [];

  var result = [];
  var trend  = 1;
  var sar    = candles[0].low;
  var ep     = candles[0].high;
  var af     = step;

  for (var i = 1; i < candles.length; i++) {
    var prev   = candles[i - 1];
    var curr   = candles[i];
    var newSar = sar + af * (ep - sar);

    if (trend === 1) {
      newSar = Math.min(newSar, prev.low, i >= 2 ? candles[i - 2].low : prev.low);
      if (curr.low < newSar) {
        trend = -1; newSar = ep; ep = curr.low; af = step;
      } else {
        if (curr.high > ep) { ep = curr.high; af = Math.min(af + step, max); }
      }
    } else {
      newSar = Math.max(newSar, prev.high, i >= 2 ? candles[i - 2].high : prev.high);
      if (curr.high > newSar) {
        trend = 1; newSar = ep; ep = curr.high; af = step;
      } else {
        if (curr.low < ep) { ep = curr.low; af = Math.min(af + step, max); }
      }
    }
    sar = newSar;
    result.push({ sar: parseFloat(sar.toFixed(2)), trend: trend });
  }
  return result;
}

// ── IST helpers ───────────────────────────────────────────────────────────────

function toIST(unixSec) {
  return new Date(unixSec * 1000).toLocaleString("en-US", { timeZone: "Asia/Kolkata", hour12: false });
}

function getISTHHMM(unixSec) {
  var d = new Date(new Date(unixSec * 1000).toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  return d.getHours() * 60 + d.getMinutes();
}

/** Get IST date string "YYYY-MM-DD" from unix seconds */
function getISTDateStr(unixSec) {
  var d = new Date(unixSec * 1000);
  return d.toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" }); // "2026-03-01"
}

// ── Opening Range State (per-day, reset on new IST date) ─────────────────────

var _orState = {
  date:     null,   // IST date string when OR was computed
  high:     null,   // OR High
  low:      null,   // OR Low
  range:    null,   // OR_HIGH - OR_LOW
  complete: false,  // true once 4 candles have formed (>= 10:15 AM candle close)
};

// ── Daily trade counter (max 2 trades per day) ────────────────────────────────
var _dailyTrades = {
  date:        null,
  count:       0,
  ceSLHit:     false, // true if a CE trade was stopped out today → no more CE
  peSLHit:     false, // true if a PE trade was stopped out today → no more PE
};

// ── Opening Range calculation ─────────────────────────────────────────────────

/**
 * Compute the Opening Range from today's candles.
 * OR = High and Low of the first 4 completed 15-min candles (9:15–10:15 AM).
 * A 15-min candle at time T covers T → T+15min.
 * So the 4th candle closes at 10:15 AM (candle.time = 10:00 AM → closes 10:15 AM).
 *
 * @param {Array} candles — all available candles (may span multiple days)
 * @param {string} todayStr — "YYYY-MM-DD" in IST
 * @returns {{ high, low, range, complete, candles: [] }}
 */
function computeOR(candles, todayStr) {
  // Filter to today's candles only
  var todayCandles = candles.filter(function(c) {
    return getISTDateStr(c.time) === todayStr;
  });

  // Opening range = candles where close time <= 10:15 AM
  // 15-min candle with time=9:15 closes at 9:30, time=9:30 closes at 9:45, etc.
  // We want candles starting at 9:15, 9:30, 9:45, 10:00 (closes 10:15)
  // time in unix seconds: 9:15=555min, 9:30=570, 9:45=585, 10:00=600
  var OR_CANDLES_END_MIN = 600; // 10:00 AM candle (closes 10:15) is the last OR candle

  var orCandles = todayCandles.filter(function(c) {
    var hhmm = getISTHHMM(c.time);
    return hhmm >= 555 && hhmm <= OR_CANDLES_END_MIN;
  });

  if (orCandles.length < 4) {
    return { complete: false, high: null, low: null, range: null, orCandles: orCandles };
  }

  var orHigh = Math.max.apply(null, orCandles.map(function(c) { return c.high; }));
  var orLow  = Math.min.apply(null, orCandles.map(function(c) { return c.low;  }));
  var range  = parseFloat((orHigh - orLow).toFixed(2));

  return { complete: true, high: orHigh, low: orLow, range: range, orCandles: orCandles };
}

// ── Main signal function ──────────────────────────────────────────────────────

/**
 * getSignal(candles)
 *
 * Called on every candle close (and intra-candle tick for live entry).
 * Returns: { signal, reason, stopLoss, ...indicators }
 */
function getSignal(candles) {
  var MIN_CANDLES = 20; // RSI(14) needs 14 + a few warm-up candles

  if (candles.length < MIN_CANDLES) {
    return {
      signal:   "NONE",
      reason:   "Warming up (" + candles.length + "/" + MIN_CANDLES + " candles)",
      stopLoss: null,
    };
  }

  var signalCandle = candles[candles.length - 1];
  var todayStr     = getISTDateStr(signalCandle.time);
  var candleMin    = getISTHHMM(signalCandle.time);

  // ── Reset daily state on new day ─────────────────────────────────────────
  if (_dailyTrades.date !== todayStr) {
    _dailyTrades = { date: todayStr, count: 0, ceSLHit: false, peSLHit: false };
  }

  // ── Recompute OR if new day or not yet computed ───────────────────────────
  if (_orState.date !== todayStr) {
    var orResult = computeOR(candles, todayStr);
    _orState = {
      date:     todayStr,
      high:     orResult.high,
      low:      orResult.low,
      range:    orResult.range,
      complete: orResult.complete,
    };
  }

  // ── OR not complete yet — wait for 4 candles ─────────────────────────────
  if (!_orState.complete) {
    return {
      signal:   "NONE",
      reason:   "OR forming — need candles up to 10:00 AM (have " + 
                candles.filter(function(c){ return getISTDateStr(c.time) === todayStr; }).length + " today)",
      stopLoss: null,
      orHigh:   _orState.high,
      orLow:    _orState.low,
    };
  }

  // ── Trading window: 10:15 AM – 3:00 PM (candles from 10:15 onwards) ──────
  // candleMin is the candle START time. 10:15 candle starts at 10:15.
  if (candleMin < 615) { // < 10:15 AM
    return {
      signal:   "NONE",
      reason:   "Waiting for OR to complete (inside OR window)",
      stopLoss: null,
      orHigh:   _orState.high,
      orLow:    _orState.low,
      orRange:  _orState.range,
    };
  }
  if (candleMin >= 900) { // >= 3:00 PM
    return {
      signal:   "NONE",
      reason:   "After 3:00 PM — no new entries",
      stopLoss: null,
      orHigh:   _orState.high,
      orLow:    _orState.low,
    };
  }

  // ── OR range must be meaningful (>= 30 pts) ───────────────────────────────
  var MIN_OR_RANGE = 20; // minimum OR width to avoid whipsaw on very flat opens
  if (_orState.range < MIN_OR_RANGE) {
    return {
      signal:   "NONE",
      reason:   "OR range too narrow (" + _orState.range + " pts < " + MIN_OR_RANGE + " pts min) — skip day",
      stopLoss: null,
      orHigh:   _orState.high,
      orLow:    _orState.low,
      orRange:  _orState.range,
    };
  }

  // ── Max 2 trades per day ──────────────────────────────────────────────────
  if (_dailyTrades.count >= 2) {
    return {
      signal:   "NONE",
      reason:   "Max 2 trades/day reached",
      stopLoss: null,
      orHigh:   _orState.high,
      orLow:    _orState.low,
    };
  }

  // ── Indicators ────────────────────────────────────────────────────────────
  var closes = candles.map(function(c) { return c.close; });

  var rsiArr = RSI.calculate({ period: 14, values: closes });
  var rsi    = rsiArr.length > 0 ? rsiArr[rsiArr.length - 1] : 50;

  var sarArr  = calcSAR(candles);
  var currSAR = sarArr.length > 0 ? sarArr[sarArr.length - 1] : null;

  // ── Breakout conditions ───────────────────────────────────────────────────
  // Breakout: close must exceed OR High/Low (no extra buffer — keeps it simple and sensitive)
  var breakoutCE_level = _orState.high;
  var breakoutPE_level = _orState.low;

  var ceBreakout = signalCandle.close > breakoutCE_level;
  var peBreakout = signalCandle.close < breakoutPE_level;

  // Candle body size as % of OR range (filter weak breakouts)
  var candleBody     = Math.abs(signalCandle.close - signalCandle.open);
  var bodyPctOfRange = _orState.range > 0 ? (candleBody / _orState.range) : 0;
  var MIN_BODY_PCT   = 0.05; // 5% of OR range — only blocks pure wick pokes

  // RSI thresholds
  var RSI_CE_MIN = 50; // RSI > 50 = bullish momentum confirms CE breakout
  var RSI_PE_MAX = 50; // RSI < 50 = bearish momentum confirms PE breakdown

  // SAR stop-loss
  var sarSL = currSAR ? currSAR.sar : null;

  var base = {
    orHigh:      _orState.high,
    orLow:       _orState.low,
    orRange:     _orState.range,
    breakoutCE:  breakoutCE_level,
    breakoutPE:  breakoutPE_level,
    rsi:         parseFloat(rsi.toFixed(1)),
    sarSL:       sarSL,
    sarTrend:    currSAR ? (currSAR.trend === 1 ? "BULLISH" : "BEARISH") : "N/A",
    candleBody:  parseFloat(candleBody.toFixed(2)),
    bodyPct:     parseFloat((bodyPctOfRange * 100).toFixed(1)),
  };

  // ── BUY_CE — Bullish Breakout ─────────────────────────────────────────────
  if (ceBreakout && !_dailyTrades.ceSLHit) {
    if (rsi < RSI_CE_MIN) {
      return Object.assign({}, base, {
        signal: "NONE",
        reason: "CE breakout but RSI=" + rsi.toFixed(1) + " < " + RSI_CE_MIN + " — weak momentum",
        stopLoss: null,
      });
    }
    if (bodyPctOfRange < MIN_BODY_PCT) {
      return Object.assign({}, base, {
        signal: "NONE",
        reason: "CE breakout but candle body " + (bodyPctOfRange*100).toFixed(1) + "% < " + (MIN_BODY_PCT*100) + "% of OR range — wick breakout, skip",
        stopLoss: null,
      });
    }
    // Stop loss: OR_LOW by default, tightened by SAR if SAR is above OR_LOW
    var slCE = _orState.low;
    if (sarSL && currSAR.trend === 1 && sarSL > slCE) {
      slCE = parseFloat(sarSL.toFixed(2)); // SAR is closer — tighter SL
    }
    return Object.assign({}, base, {
      signal: "BUY_CE",
      reason: "ORB CE breakout: close " + signalCandle.close + " > OR_H " + breakoutCE_level +
              " | RSI=" + rsi.toFixed(1) +
              " | Body=" + (bodyPctOfRange*100).toFixed(0) + "% OR | SL=" + slCE,
      stopLoss: slCE,
    });
  }

  // ── BUY_PE — Bearish Breakdown ────────────────────────────────────────────
  if (peBreakout && !_dailyTrades.peSLHit) {
    if (rsi > RSI_PE_MAX) {
      return Object.assign({}, base, {
        signal: "NONE",
        reason: "PE breakdown but RSI=" + rsi.toFixed(1) + " > " + RSI_PE_MAX + " — weak momentum",
        stopLoss: null,
      });
    }
    if (bodyPctOfRange < MIN_BODY_PCT) {
      return Object.assign({}, base, {
        signal: "NONE",
        reason: "PE breakdown but candle body " + (bodyPctOfRange*100).toFixed(1) + "% < " + (MIN_BODY_PCT*100) + "% of OR range — wick breakdown, skip",
        stopLoss: null,
      });
    }
    // Stop loss: OR_HIGH by default, tightened by SAR if SAR is below OR_HIGH
    var slPE = _orState.high;
    if (sarSL && currSAR.trend === -1 && sarSL < slPE) {
      slPE = parseFloat(sarSL.toFixed(2)); // SAR is closer — tighter SL
    }
    return Object.assign({}, base, {
      signal: "BUY_PE",
      reason: "ORB PE breakdown: close " + signalCandle.close + " < OR_L " + breakoutPE_level +
              " | RSI=" + rsi.toFixed(1) +
              " | Body=" + (bodyPctOfRange*100).toFixed(0) + "% OR | SL=" + slPE,
      stopLoss: slPE,
    });
  }

  // ── No signal ─────────────────────────────────────────────────────────────
  var waitReason = "";
  if (!ceBreakout && !peBreakout) {
    waitReason = "Inside OR range (" + _orState.low + " – " + _orState.high + ")" +
                 " | close=" + signalCandle.close;
  } else if (ceBreakout && _dailyTrades.ceSLHit) {
    waitReason = "CE SL hit earlier today — no more CE entries";
  } else if (peBreakout && _dailyTrades.peSLHit) {
    waitReason = "PE SL hit earlier today — no more PE entries";
  }

  return Object.assign({}, base, {
    signal:   "NONE",
    reason:   waitReason || "No valid breakout | RSI=" + rsi.toFixed(1) + " | close=" + signalCandle.close + " OR=" + _orState.low + "-" + _orState.high,
    stopLoss: null,
  });
}

/**
 * Called by paper/live trade engine after a stop-loss exit,
 * so we can mark that direction as exhausted for today.
 * Paper/live engines call this optionally — graceful if not called.
 */
function onStopLossHit(side) {
  if (side === "CE") _dailyTrades.ceSLHit = true;
  if (side === "PE") _dailyTrades.peSLHit = true;
  _dailyTrades.count++;
}

/** Called after any trade close (win or loss) to increment trade count */
function onTradeClosed() {
  _dailyTrades.count++;
}

/**
 * reset() — called at the start of each backtest run to wipe module-level state.
 * Without this, running backtest twice in the same server session would carry
 * over OR state and daily trade counts from the previous run.
 */
function reset() {
  _orState     = { date: null, high: null, low: null, range: null, complete: false };
  _dailyTrades = { date: null, count: 0, ceSLHit: false, peSLHit: false };
}

module.exports = {
  NAME:          NAME,
  DESCRIPTION:   DESCRIPTION,
  getSignal:     getSignal,
  onStopLossHit: onStopLossHit,
  onTradeClosed: onTradeClosed,
  reset:         reset,
};
