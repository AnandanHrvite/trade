require("dotenv").config();
const fyers = require("../config/fyers");
const { toDateString } = require("../utils/time");
const { getLotQty } = require("../config/instrument");

function maxDaysForResolution(resolution) {
  if (["D", "W", "M"].includes(resolution)) return 365 * 10;
  if (["1", "2", "3"].includes(String(resolution))) return 30;
  return 100;
}
function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

async function fetchChunk(symbol, resolution, from, to) {
  const params = { symbol, resolution: String(resolution), date_format: "1", range_from: from, range_to: to, cont_flag: "1" };
  console.log(`   📦 Fetching chunk: ${from} → ${to}`);
  const response = await fyers.getHistory(params);
  if (response.s !== "ok") throw new Error(`Fyers API error: ${JSON.stringify(response)}`);
  if (!response.candles || response.candles.length === 0) return [];
  return response.candles.map(([time, open, high, low, close, volume]) => ({ time, open, high, low, close, volume }));
}

async function fetchCandles(symbol, resolution, from, to) {
  const maxDays = maxDaysForResolution(resolution);
  const allCandles = [];
  let cursor = new Date(from);
  const endDate = new Date(to);
  while (cursor <= endDate) {
    const chunkEnd = new Date(cursor);
    chunkEnd.setDate(chunkEnd.getDate() + maxDays - 1);
    if (chunkEnd > endDate) chunkEnd.setTime(endDate.getTime());
    const candles = await fetchChunk(symbol, resolution, cursor.toISOString().split("T")[0], chunkEnd.toISOString().split("T")[0]);
    allCandles.push(...candles);
    cursor = new Date(chunkEnd);
    cursor.setDate(cursor.getDate() + 1);
    if (cursor <= endDate) await sleep(300);
  }
  const seen = new Set();
  const unique = allCandles.filter((c) => { if (seen.has(c.time)) return false; seen.add(c.time); return true; });
  unique.sort((a, b) => a.time - b.time);
  console.log(`   ✅ Total candles fetched: ${unique.length}`);
  return unique;
}

function toIST(unixSec) {
  return new Date(unixSec * 1000).toLocaleString("en-IN", { timeZone: "Asia/Kolkata", hour12: false });
}

/** Get IST date string "YYYY-MM-DD" from unix seconds */
function getISTDateStr(unixSec) {
  return new Date(unixSec * 1000).toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
}

/** Get IST hour*60+min from unix seconds */
function getISTHHMM(unixSec) {
  const d = new Date(new Date(unixSec * 1000).toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
  return d.getHours() * 60 + d.getMinutes();
}

/**
 * BACKTEST ENGINE — mirrors paper trade logic exactly
 *
 * ENTRY (same as paper trade):
 *   Signal comes from strategy.getSignal(window)
 *   Entry price = candle.close
 *   Stop loss   = from strategy.getSignal(prevWindow) — closed candles only, NOT entry candle
 *                 (mirrors paper/live fix: SL always from last fully closed candle's SAR)
 *
 * EXIT (same priority as paper trade):
 *   Rule 1 — 50% candle rule (skipped on entry candle itself, same as paper trade)
 *   Rule 2+3 — Intra-candle trail SL simulation (from first favourable move, 10pt gap)
 *              + SAR trailing SL (tighten only on each candle)
 *   Rule 4 — Opposite signal
 *   Rule 5 — EOD square-off at 3:20 PM IST (PER DAY)
 *
 * FIX v20:
 *   - EOD exit now fires per-day at 3:20 PM, not just at the very last candle
 *   - strategy.onTradeClosed() and onStopLossHit() called after every exit
 *     so ORB daily trade counters work correctly in backtest
 * FIX v30 (sync with paper/live):
 *   - Trail SL: removed 15pt trigger threshold — trails from first favourable move
 *   - SL at entry: taken from prev window (closed candles only), not entry candle
 *   - 50% rule: skipped on the entry candle itself (applied from next candle onwards)
 */
function runBacktest(candles, strategy, capital) {
  const trades    = [];
  let position    = null;
  const BROKERAGE = 80;
  const LOT_SIZE  = getLotQty();

  // Trail gap only — no trigger threshold (matches paper/live v30)
  const TRAIL_GAP_PTS = 10;

  // Reset strategy module-level state (e.g. ORB daily counters) before each run
  if (typeof strategy.reset === "function") strategy.reset();

  console.log("\n══════════════════════════════════════════════");
  console.log(`🔍 BACKTEST — ${strategy.NAME}`);
  console.log(`   Entry : signal from strategy at candle close`);
  console.log(`   Exit  : 50% rule + trail SL + SAR SL + opposite signal + EOD/day`);
  console.log(`   Brok  : ₹${BROKERAGE} per trade`);
  console.log("══════════════════════════════════════════════");

  for (let i = 30; i < candles.length; i++) {
    const candle     = candles[i];
    const prevCandle = candles[i - 1];

    // ── Per-day EOD detection ─────────────────────────────────────────────────
    // A candle is the last of its trading day if the NEXT candle is a different
    // IST date OR there is no next candle (final candle of entire run).
    const candleDate = getISTDateStr(candle.time);
    const nextCandle = candles[i + 1] || null;
    const nextDate   = nextCandle ? getISTDateStr(nextCandle.time) : null;
    const isLastCandleOfDay = !nextCandle || nextDate !== candleDate;

    // Also check time — force EOD at 3:20 PM regardless
    const candleMin     = getISTHHMM(candle.time);
    const isEODcandle   = isLastCandleOfDay || candleMin >= 920;

    // ── Get signal from current window (entry candle included) ────────────────
    const window = candles.slice(0, i + 1);
    const { signal, reason, stopLoss: signalSL, ...indicators } = strategy.getSignal(window);

    // ── SL FIX: get stop-loss from PREVIOUS window (closed candles only) ──────
    // Mirrors paper/live: SL always taken from last fully closed candle's SAR,
    // not from the entry candle itself (whose SAR may differ at mid-candle).
    const prevWindow = candles.slice(0, i);
    const { stopLoss: prevSignalSL } = strategy.getSignal(prevWindow);

    // ── UPDATE TRAILING SAR SL (tighten only) ────────────────────────────────
    if (position && signalSL !== null && signalSL !== undefined) {
      const oldSL   = position.stopLoss;
      const tighten = position.side === "CE"
        ? (oldSL === null || signalSL > oldSL)
        : (oldSL === null || signalSL < oldSL);
      if (tighten) position.stopLoss = signalSL;
    }

    // ── SIMULATE INTRA-CANDLE TRAIL ───────────────────────────────────────────
    // Trail from the very first favourable move — no minimum trigger distance.
    // Uses candle high/low as best price proxy (tick-level not available in backtest).
    // Mirrors paper/live: SL = bestPrice ± TRAIL_GAP_PTS, tighten only.
    if (position) {
      if (position.side === "CE") {
        const bestThisCandle = candle.high;
        if (!position.bestPrice || bestThisCandle > position.bestPrice) position.bestPrice = bestThisCandle;
        const trailSL = parseFloat((position.bestPrice - TRAIL_GAP_PTS).toFixed(2));
        if (trailSL > position.stopLoss) position.stopLoss = trailSL;
      } else {
        const bestThisCandle = candle.low;
        if (!position.bestPrice || bestThisCandle < position.bestPrice) position.bestPrice = bestThisCandle;
        const trailSL = parseFloat((position.bestPrice + TRAIL_GAP_PTS).toFixed(2));
        if (trailSL < position.stopLoss) position.stopLoss = trailSL;
      }
    }

    // ── EXIT CHECK ────────────────────────────────────────────────────────────
    if (position) {
      let exitReason = null;
      let exitPrice  = candle.close;

      // Rule 1: 50% candle rule
      // Skip on the entry candle itself — mirrors paper/live which skips the entry bar.
      // prevMid = mid of the candle closed just BEFORE entry (fixed at entry time).
      const isEntryCandle = candle.time === position.entryTime;
      if (!isEntryCandle) {
        const prevMid = position.entryPrevMid;
        if (position.side === "CE" && candle.low < prevMid) {
          exitReason = `50% rule — low ${candle.low} < prev mid ${prevMid}`;
          exitPrice  = prevMid;
        } else if (position.side === "PE" && candle.high > prevMid) {
          exitReason = `50% rule — high ${candle.high} > prev mid ${prevMid}`;
          exitPrice  = prevMid;
        }
      }

      // Rule 2+3: SL or trail SL
      if (!exitReason && position.stopLoss !== null && position.stopLoss !== undefined) {
        if (position.side === "CE" && candle.close < position.stopLoss) {
          exitReason = `SL hit — close ${candle.close} < SL ${position.stopLoss}`;
          exitPrice  = position.stopLoss;
        } else if (position.side === "PE" && candle.close > position.stopLoss) {
          exitReason = `SL hit — close ${candle.close} > SL ${position.stopLoss}`;
          exitPrice  = position.stopLoss;
        }
      }

      // Rule 4: Opposite signal
      if (!exitReason && signal === (position.side === "CE" ? "BUY_PE" : "BUY_CE")) {
        exitReason = "Opposite signal exit";
        exitPrice  = candle.close;
      }

      // Rule 5: EOD square-off — PER DAY at 3:20 PM (FIXED)
      if (!exitReason && isEODcandle) {
        exitReason = `EOD square-off ${candleMin >= 920 ? "3:20 PM" : "(last candle of day)"}`;
        exitPrice  = candle.close;
      }

      if (exitReason) {
        const pnlPoints = parseFloat(((exitPrice - position.entryPrice) * (position.side === "CE" ? 1 : -1)).toFixed(2));
        trades.push({
          side:        position.side,
          entryTime:   toDateString(position.entryTime),
          exitTime:    toDateString(candle.time),
          entryTs:     position.entryTime,
          exitTs:      candle.time,
          entryPrice:  position.entryPrice,
          exitPrice,
          stopLoss:    position.stopLoss || "N/A",
          bestPrice:   position.bestPrice || null,
          pnl:         pnlPoints,
          exitReason,
          entryReason: position.entryReason,
          indicators:  position.indicators,
        });
        console.log(`  🚪 EXIT ${position.side} @ ${exitPrice}  PnL=${pnlPoints}  reason=${exitReason}`);

        // ── Notify strategy: update daily counters (fixes ORB max-trades in backtest)
        const exitedSide = position.side;
        position = null;
        if (typeof strategy.onTradeClosed === "function") strategy.onTradeClosed();
        const isSL = exitReason.toLowerCase().includes("sl hit");
        if (isSL && typeof strategy.onStopLossHit === "function") strategy.onStopLossHit(exitedSide);
      }
    }

    // ── ENTRY ─────────────────────────────────────────────────────────────────
    // Don't enter on EOD candle — position would be immediately squared off.
    // SL from prevWindow (closed candles only) — matches paper/live fix.
    // entryPrevMid = mid of candle[i-1] (closed just before entry) — fixed for 50% rule.
    if (!position && !isEODcandle && (signal === "BUY_CE" || signal === "BUY_PE")) {
      const side = signal === "BUY_CE" ? "CE" : "PE";
      const entryPrevMid = parseFloat(((prevCandle.high + prevCandle.low) / 2).toFixed(2));
      position = {
        side,
        entryPrice:   candle.close,
        entryTime:    candle.time,
        entryReason:  reason,
        stopLoss:     prevSignalSL || null,   // SL from closed candles only
        bestPrice:    null,
        entryPrevMid,                          // fixed mid for 50% rule — never changes
        indicators,
      };
      console.log(`  ✅ ENTER ${side} @ ${candle.close} [${toIST(candle.time)}]  SL=${prevSignalSL}  | ${reason}`);
    }
  }

  // Square off any still-open position at end of run
  if (position) {
    const lastCandle = candles[candles.length - 1];
    const pnlPoints  = parseFloat(((lastCandle.close - position.entryPrice) * (position.side === "CE" ? 1 : -1)).toFixed(2));
    trades.push({
      side:        position.side,
      entryTime:   toDateString(position.entryTime),
      exitTime:    toDateString(lastCandle.time),
      entryTs:     position.entryTime,
      exitTs:      lastCandle.time,
      entryPrice:  position.entryPrice,
      exitPrice:   lastCandle.close,
      stopLoss:    position.stopLoss || "N/A",
      bestPrice:   position.bestPrice || null,
      pnl:         pnlPoints,
      exitReason:  "EOD square-off (run end)",
      entryReason: position.entryReason,
      indicators:  position.indicators,
    });
    if (typeof strategy.onTradeClosed === "function") strategy.onTradeClosed();
  }

  console.log("\n══════════════════════════════════════════════\n");

  const totalPnl      = trades.reduce((sum, t) => sum + t.pnl, 0);
  const wins          = trades.filter((t) => t.pnl > 0);
  const losses        = trades.filter((t) => t.pnl <= 0);
  const maxDrawdown   = trades.reduce((dd, t) => Math.min(dd, t.pnl), 0);  // worst single loss
  const totalDrawdown = losses.reduce((sum, t) => sum + t.pnl, 0);         // sum of all losses
  const maxProfit     = trades.reduce((mp, t) => Math.max(mp, t.pnl), 0);  // best single win
  const avgWin        = wins.length   ? wins.reduce((s, t)   => s + t.pnl, 0) / wins.length   : 0;
  const avgLoss       = losses.length ? losses.reduce((s, t) => s + t.pnl, 0) / losses.length : 0;
  const riskReward    = avgLoss !== 0 ? Math.abs(avgWin / avgLoss) : null;

  return {
    summary: {
      strategy:      strategy.NAME,
      description:   strategy.DESCRIPTION,
      totalTrades:   trades.length,
      wins:          wins.length,
      losses:        losses.length,
      winRate:       trades.length ? `${((wins.length / trades.length) * 100).toFixed(1)}%` : "N/A",
      totalPnl:      parseFloat(totalPnl.toFixed(2)),
      maxProfit:     parseFloat(maxProfit.toFixed(2)),
      maxDrawdown:   parseFloat(maxDrawdown.toFixed(2)),
      totalDrawdown: parseFloat(totalDrawdown.toFixed(2)),
      avgWin:        parseFloat(avgWin.toFixed(2)),
      avgLoss:       parseFloat(avgLoss.toFixed(2)),
      riskReward:    riskReward ? `1:${riskReward.toFixed(2)}` : "N/A",
      finalCapital:  parseFloat((capital + totalPnl).toFixed(2)),
    },
    trades,
  };
}

module.exports = { fetchCandles, runBacktest };
