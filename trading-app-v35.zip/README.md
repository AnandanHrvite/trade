# Murugan Thunai — Trading BOT v19

NIFTY algo trading | Fyers (data) + Zerodha (orders)  
Backtest · Paper Trade · Live Trade

---

## Quick Start

```bash
npm install
cp .env.example .env   # fill in your keys
node src/app.js        # or: npm run dev
```

Open http://localhost:3000

---

## .env Configuration

```env
# ─── Fyers ──────────────────────────────
APP_ID=your_fyers_app_id
SECRET_KEY=your_fyers_secret
REDIRECT_URL=http://localhost:3000/auth/callback
ACCESS_TOKEN=          # auto-filled after /auth/login

# ─── Zerodha ────────────────────────────
ZERODHA_API_KEY=your_zerodha_api_key
ZERODHA_API_SECRET=your_zerodha_secret
ZERODHA_REDIRECT_URL=http://localhost:3000/auth/zerodha/callback

# ─── Trading ────────────────────────────
ACTIVE_STRATEGY=STRATEGY_1         # STRATEGY_1 or STRATEGY_2
LIVE_TRADE_ENABLED=false           # set true when ready
PAPER_TRADE_CAPITAL=100000

# ─── Timeframe ──────────────────────────
TRADE_RESOLUTION=15    # 3, 5, 15, or 60 (minutes)
                       # STRATEGY_1 (SAR_EMA_RSI): use 15 (recommended)
                       # STRATEGY_2 (15min ORB):   use 15

# ─── Security ───────────────────────────
API_SECRET=            # optional — protects action endpoints
```

---

## Strategies

### STRATEGY_1 — SAR_EMA9_RSI (5-min)
- EMA9 intra-candle touch trigger
- SAR already positioned or just flipped
- RSI > 51 (CE) / < 49 (PE)
- SAR trailing stop-loss

### STRATEGY_2 — 15Min_ORB (Opening Range Breakout)
- Opening Range = High/Low of first 4 candles (9:15–10:15 AM)
- Breakout: close > OR_High+0.1% with EMA20 rising + RSI > 55
- Breakdown: close < OR_Low−0.1% with EMA20 falling + RSI < 45
- Candle body must be ≥ 30% of OR range (no wick fakeouts)
- OR range must be ≥ 30 points (skip narrow/choppy opens)
- Max 2 trades per day
- SL = OR_Low (CE) or OR_High (PE), tightened by SAR

**Required:** Set `TRADE_RESOLUTION=15` in .env when using STRATEGY_2

---

## Bug Fixes (v19)

- **Reset button:** Was blocked by API_SECRET middleware — now in OPEN_PATHS
- **Zerodha false-connected:** Token was restored from disk even after abandoning
  login mid-flow. Fixed: disk token only trusted if it was validated via real
  OAuth callback. Added `/auth/zerodha/logout` to force-clear stale token.
- **Favicon:** Murugan OM icon on all pages (Dashboard, Backtest, Paper, Live)
- **3-min timeframe:** Added to backtest dropdown and TRADE_RESOLUTION support

---

## Security Notes (local use)

- App binds to `127.0.0.1` only — not reachable from network
- Set `API_SECRET` in `.env` to protect start/stop endpoints
- Zerodha token saved to `data/.zerodha_token` — delete file to force re-login
- To clear Zerodha session: visit http://localhost:3000/auth/zerodha/logout
